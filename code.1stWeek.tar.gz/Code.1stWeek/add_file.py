#!/usr/bin/env python3

import os

top_dir = '/home/shiyanlou/syl'
second_dir_A = os.path.join(top_dir,'A')
second_dir_B = os.path.join(top_dir,'B')
second_dir_C = os.path.join(top_dir,'C')
os.mkdir(top_dir)
os.mkdir(second_dir_A)
os.mkdir(second_dir_B)
os.mkdir(second_dir_C)

third_level_file_in_A = os.path.join(second_dir_A,'__init__.py')
third_level_file_in_B = os.path.join(second_dir_B,'__init__.py')
third_level_file_in_C = os.path.join(second_dir_C,'__init__.py')
f1 = os.open(third_level_file_in_A,os.O_CREAT)
f2 = os.open(third_level_file_in_B,os.O_CREAT)
f3 = os.open(third_level_file_in_C,os.O_CREAT)
os.close(f1)
os.close(f2)
os.close(f3)

os.system("tree syl")
