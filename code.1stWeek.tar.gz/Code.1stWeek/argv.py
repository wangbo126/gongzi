#!/usr/bin/env python3
import sys

print(sys.argv)
