#!/usr/bin/env python3

import sys

class Cp():
    def cpfile(self,src,dst):
        i = 1
        with open(src,'r') as srcfile:
            with open(dst,'w') as dstfile:
                for line in srcfile:
                    dstfile.write("{} ".format(i))
                    dstfile.write(line)
                    i += 1

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage:{} srcfile dstfile".format(sys.argv[0]))
        exit(-1)
    srcfilename = sys.argv[1]
    dstfilename = sys.argv[2]
    mycp = Cp()
    mycp.cpfile(srcfilename,dstfilename)



