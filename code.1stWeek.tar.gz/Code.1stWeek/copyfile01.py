#!/usr/bin/env python3

import sys

def copy_file(src,dst):
    with open(src,'r') as srcfile:
        with open(dst,'w') as dstfile:
            for i,x in enumerate(srcfile):
                if (i == 0):
                    continue
                dstfile.write(i)
                dstfile.write(x)

