#!/usr/bin/env python3
import sys

def char_count(str):
    char_list = set(str)
    for ch in char_list:
        print(ch,str.count(ch))

if __name__ == '__main__':
    char_count(sys.argv[1])


