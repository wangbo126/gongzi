#!/usr/bin/env python3
import sys

def handle_data(arg):
    myList = arg.split(':')
    output_dict[myList[0]] = myList[1]

def print_data(key,out_dict):
    print("ID:{} Name:{}".format(key,out_dict))


output_dict = {} ## my global var ##

if __name__ == '__main__':

    for arg in sys.argv[1:]:
        handle_data(arg)

    for key in output_dict:
        print_data(key,output_dict[key])

