#!/usr/bin/env python3

class Animal(object):
    def __init__(self,name):
        self._name = name
    def get_name(self):
        return self._name.lower().capitalize()
    def set_name(self,value):
        self._name = value
    def make_sound(self):
        pass

class Dog(Animal):
    def __init__(self,name,age):
        super().__init__(name)
        self.age = age

    def make_sound(self):
        print(self.get_name() + 'is making sound wang wang wang..')

    def dogage(self):
        print(self.get_name() , self.age)

class Cat(Animal):
    def make_sound(self):
        print(self.get_name() + 'is making sound miu miu miu...')

#dog = Dog('wang cai',3)
#cat = Cat('Kitty')
#dog.make_sound()
#dog.dogage()
#cat.make_sound()

animals = [ Dog('wangcai',3),Cat('Kitty'),Dog('laifu',6),Cat('Betty')]
for animal in animals:
    animal.make_sound()

