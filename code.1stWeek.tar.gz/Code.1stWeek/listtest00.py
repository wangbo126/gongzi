#!/usr/bin/env python3
import sys

Le3=[]
G3=[]

#print("length of sys.argv: ",len(sys.argv))
for myarg in sys.argv[1:]:
    if len(myarg) <= 3 :
        Le3.append(myarg)
    else:
        G3.append(myarg)
print("Para. Le3 :",Le3)
print("Para. G3  :",G3)

