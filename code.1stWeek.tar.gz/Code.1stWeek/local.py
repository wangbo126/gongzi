#!/usr/bin/env python3
a = 9
def change():
    global a
    print(a)
    a = 900

print("Before",a)
print("inside",end=' ')
change()
print("After",a)
