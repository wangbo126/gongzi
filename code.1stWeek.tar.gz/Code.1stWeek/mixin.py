#!/usr/bin/env python3

class A:
    def __init__(self):
        self.name = 'xiaoming'
    def test(self):
        print('----testA----')

class B:
    def __init__(self):
        self.age=9
    def test(self):
        print('----testB----')

class Person(A,B):
    pass

person = Person()
person.test()
print(Person.mro())


