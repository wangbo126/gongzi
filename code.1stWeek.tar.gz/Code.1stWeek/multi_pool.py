#!/usr/bin/env python3
import os,time,random
from multiprocessing import Pool

def task(name):
    print('Task {} starting,PID:{}'.format(name,os.getpid()))
    start = time.time()

    time.sleep(random.random() * 3)
    end = time.time()
    print('Task {} ending,used time:{:.2f}s'.format(name,(end-start)))

if __name__ == '__main__':
    print('Current main process,PID:{}'.format(os.getpid()))
    print('_________________________')

    p = Pool(4)
    for i in range(1,6):
        p.apply_async(task,args=(i,))

    p.close()
    print('Beginning sub-process...')
    p.join()
    print('________________________')
    print('All of sub-process have been ending,Current process is main,PID:{}'.format(os.getpid()))

