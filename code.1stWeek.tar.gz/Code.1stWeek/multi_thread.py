#!/usr/bin/env python3
import threading

def hello(name):
    print('Current is sub-threading,threading-ID:{}'.format(threading.get_ident()))
    print('Hello '+ name)

def main():
    print('Current is main-threading,threading-ID:{}'.format(threading.get_ident()))
    print('----------------------------')
    
    t = threading.Thread(target=hello,args=('shiyanlou',))
    t.start()
    t.join()
    print('----------------------------')
    print('Current is main-threading,threading-ID:{}'.format(threading.get_ident()))

if __name__ == '__main__':
    main()
    

