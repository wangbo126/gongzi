#!/usr/bin/env python3

import json

mylist = [{
            'user_id': 1000,
            'name': 'Shiyan',
            'pass': 10,
            'study_time': 50,
           },
           {
            'user_id': 2000,
            'name': 'Lou',
            'pass': 15,
            'study_time': 171,
            }]

with open("/tmp/jsontest.json","w") as myfile:
    json.dump(mylist,myfile)

with open('/tmp/jsontest.json','r') as myfile2:
        mylist2 = json.load(myfile2)
print(mylist2)
