#!/usr/bin/env python3
import sys

arg_set=set()
for arg in sys.argv[1:]:
    arg_set.add(arg)
print(arg_set)

