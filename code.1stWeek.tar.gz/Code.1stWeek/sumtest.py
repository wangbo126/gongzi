#!/usr/bin/env python3

a=int(input("the first num:"))
b=int(input("the second num:"))
c=int(input("the third num:"))

print("a is {},b is {},c is {},a+b+c={}".format(a,b,c,a+b+c))
print("a is %d,b is %d,c is %d,a+b+c=%d"%(a,b,c,a+b+c))

