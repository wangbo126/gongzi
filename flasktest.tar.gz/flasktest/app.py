from flask import Flask
from flask import url_for
from flask import redirect
from flask import render_template
from flask import request

app = Flask(__name__)
app.config['TEMPLATE_AUTO_RELOAD'] = True

@app.route("/")
def index():
    course = {
            'python':'lou+ python',
            'java':'java base',
            'bigdata':'spark sql',
            'teacher':'shixiaolou',
            'is_unique':False,
            'has_tag':True,
            'tags':['c','c++','docker']
            }
    return render_template('index.html',course=course)
    #return "Hello Shiyanlou!"

@app.route("/flasktest/")
def index2():
    return "Hello Shiyanlou in flasktest"

@app.route('/user/<username>')
def user_index(username):
    return 'Hello {}'.format(username)

@app.route('/post/<int:post_id>')
def show_post(post_id):
    return 'Post {}'.format(post_id)

@app.route('/courses/<name>')
def courses(name):
    #return '/courses/{}'.format(name)
    return render_template('courses.html',coursename=name)

@app.route('/test')
def test():
    #print(url_for('index'))
    #print(url_for('user_index',username='shixiaolou'))
    #print(url_for('show_post',post_id=1,_external=True))
    #print(url_for('show_post',post_id=2,q='python 03'))
    #print(url_for('show_post',post_id=2,q='python ke yi'))
    #print(url_for('show_post',post_id=2,_anchor='a'))
    print('http://127.0.0.1:5000{}'.format(url_for('courses',name='java')))
    return redirect(url_for('index'))

@app.route('/<username>')
def hello(username):
    if username == 'shixiaolou':
        return 'hello {}'.format(username)
    else:
        return redirect(url_for('index'))

@app.route('/httptest',methods=['GET','POST'])
def httptest():
    if request.method == 'GET':
        print('t:',request.args.get('t'))
        print('q:',request.args.get('q'))
        return "It is a get request!"
    elif request.method == 'POST':
        print('Q:',request.form.getlist('Q'))
        return "It is a post request!"




if __name__ == '__main__':
    app.run

