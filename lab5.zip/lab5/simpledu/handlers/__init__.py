from .front import front
from .course import course
from .admin import admin
