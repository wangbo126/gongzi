from flask import Blueprint

company = Blueprint('company', __name__, url_prefix='/companies')
