from flask import Blueprint

job = Blueprint('job', __name__, url_prefix='/jobs')
