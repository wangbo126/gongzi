from seiya.db.base import engine, Base

Base.metadata.create_all(engine)
