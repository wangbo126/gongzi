from .favorite_product import FavoriteProduct, FavoriteProductSchema
from .product import Product, ProductSchema
from .shop import Shop, ShopSchema
