from flask import Flask,abort
import json
from flask import render_template
import os
import sys
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime



app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root@localhost/myflaskdb'
db = SQLAlchemy(app)

class File(db.Model):
    __tablename__ = 'file'
    id = db.Column(db.Integer,primary_key = True,unique = True)
    title = db.Column(db.String(80),unique = True)
    created_time = db.Column(db.DateTime)
    category_id = db.Column(db.Integer,db.ForeignKey('category.id'))
    #category_id = db.Column(db.Integer)
    content = db.Column(db.Text)

    def __init__(self,id,title,created_time,category_id,content):
        self.id = id
        self.title = title
        self.created_time = created_time
        self.category_id = category_id
        self.content = content

    def __repr__(self):
        return '<File %r>' % self.id

class Category(db.Model):
    __tablename__ = 'category'
    id = db.Column(db.Integer,primary_key = True)
    name = db.Column(db.String(80))

    def __init__(self,id,name):
        self.id = id
        self.name = name

    def __repr__(self):
        return '<Category %r>' % self.name




@app.route('/')
def index():
    title_dict = {}
    files = File.query.all()
    newspath = "/files"
    for item in files:
        newsfile = os.path.join(newspath,str(item.id))
        title_dict[item.title] = newsfile
    return render_template('index.html',title_dict=title_dict)

#def index():
#   #xian shi /home/shiyanlou/files/ zhong json wenjian zhong 'title' liebiao
#   mypath = "/home/shiyanlou/files"
#   newspath = "/files"
#   #title_list = []
#   title_dict = {}  
#   for f in os.listdir(mypath):
#       myfile = os.path.join(mypath,f)
#       #print(myfile)
#       newsfile = os.path.join(newspath,os.path.splitext(f)[0])
#       file_json_dict = {}
#       with open(myfile,'r') as f_json:
#           file_json_dict = json.load(f_json)
#           title_dict[file_json_dict['title']] = newsfile

#   print('title_dict = {}'.format(title_dict))
#   return render_template('index.html',title_dict=title_dict)


@app.route('/files/<file_id>')
def file(file_id):
    targetfile = File.query.filter_by(id = int(file_id)).first()
    #print('targetfile.content = {}'.format(targetfile.content))
    #targetfile_dict = {}
    #targetfile_dict[targetfile.id] = targetfile.content
    if targetfile != '':
        return render_template('file.html',targetfile=targetfile)
    else:
        abort(404)


#@app.route('/files/<filename>')
#def file(filename):
#   #read and  display the content of filename.json 
#   #if filename bu cun zai ,then display 'shiyanlou 404' 404 error page
#   mypath = "/home/shiyanlou/files"
#   mywholefile = filename + '.json'
#   newspath = "/files"
#   myfile = os.path.join(mypath,mywholefile)
#
#   if os.path.exists(myfile):
#       file_json_dict = {}
#       with open(myfile,'r') as f_json:
#           file_json_dict = json.load(f_json)
#       return render_template('file.html',file_json_dict=file_json_dict)
#   else:
#       abort(404)

@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'),404




#http://localhost:3000/ ke jin ru the page of index
if __name__ == '__main__':
    app.run(host='0.0.0.0',port=3000)
