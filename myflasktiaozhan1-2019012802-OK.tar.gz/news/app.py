from flask import Flask,abort
import json
from flask import render_template
import os
import sys



app = Flask(__name__)

@app.route('/')
def index():
   #xian shi /home/shiyanlou/files/ zhong json wenjian zhong 'title' liebiao
   mypath = "/home/shiyanlou/files"
   newspath = "/files"
   #title_list = []
   title_dict = {}  
   for f in os.listdir(mypath):
       myfile = os.path.join(mypath,f)
       #print(myfile)
       newsfile = os.path.join(newspath,os.path.splitext(f)[0])
       file_json_dict = {}
       with open(myfile,'r') as f_json:
           file_json_dict = json.load(f_json)
           title_dict[file_json_dict['title']] = newsfile

   print('title_dict = {}'.format(title_dict))
   return render_template('index.html',title_dict=title_dict)

@app.route('/files/<filename>')
def file(filename):
   #read and  display the content of filename.json 
   #if filename bu cun zai ,then display 'shiyanlou 404' 404 error page
   mypath = "/home/shiyanlou/files"
   mywholefile = filename + '.json'
   newspath = "/files"
   myfile = os.path.join(mypath,mywholefile)

   if os.path.exists(myfile):
       file_json_dict = {}
       with open(myfile,'r') as f_json:
           file_json_dict = json.load(f_json)
       return render_template('file.html',file_json_dict=file_json_dict)
   else:
       abort(404)

@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'),404




#http://localhost:3000/ ke jin ru the page of index
if __name__ == '__main__':
    app.run(host='0.0.0.0',port=3000)
