from flask import Flask
import json
from flask import render_template
import os
import sys



app = Flask(__name__)

@app.route('/')
def index():
   #xian shi /home/shiyanlou/files/ zhong json wenjian zhong 'title' liebiao
   mypath = "/home/shiyanlou/files"
   #title_list = []
   title_dict = {}  
   for f in os.listdir(mypath):
       myfile = os.path.join(mypath,f)
       print(myfile)
       file_json_dict = {}
       with open(myfile,'r') as f_json:
           file_json_dict = json.load(f_json)
           title_dict[file_json_dict['title']] = myfile

   print('title_dict = {}'.format(title_dict))
   return render_template('index.html',title_dict=title_dict)

@app.route('/files/<filename>')
def file(filename):
   #read and  display the content of filename.json 
   #if filename bu cun zai ,then display 'shiyanlou 404' 404 error page
   pass

#http://localhost:3000/ ke jin ru the page of index
if __name__ == '__main__':
    app.run
