from flask import Blueprint

admin = Blueprint('admin',__name__,url_prefix='/admin')

# route name and function name changed
@admin.route('/')
def index():
    return 'admin'
