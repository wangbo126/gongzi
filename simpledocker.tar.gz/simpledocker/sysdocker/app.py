from flask import Flask,render_template
from sysdocker.config import configs
from sysdocker.models import db,Course
from flask_migrate import Migrate
from flask_login import LoginManager
from sysdocker.models import User

def register_extensions(app):
    db.init_app(app)
    Migrate(app,db)

    login_manager = LoginManager()
    login_manager.init_app(app)

    @login_manager.user_loader
    def user_loader(id):
        return User.query.get(id)

    login_manager.login_view = 'front.login'


def register_blueprints(app):
    from .handlers import front,course,admin,containers
    app.register_blueprint(front)
    app.register_blueprint(course)
    app.register_blueprint(admin)
    app.register_blueprint(containers)



def create_app(config):
    """ App factory"""
    app = Flask(__name__)
    app.config.from_object(configs.get(config))
    #db.init_app(app) # move to register_extesions()
    #Migrate(app,db)
    register_extensions(app)
    register_blueprints(app)
    return app
