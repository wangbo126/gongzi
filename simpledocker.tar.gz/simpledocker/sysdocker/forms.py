from flask_wtf import FlaskForm
from wtforms import StringField,PasswordField,SubmitField,BooleanField
from wtforms.validators import Length,Email,EqualTo,DataRequired
from sysdocker.models import db,User
from wtforms import ValidationError
from wtforms import TextAreaField,IntegerField
from sysdocker.models import Course
from wtforms.validators import URL,NumberRange


class RegisterForm(FlaskForm):
    username = StringField('Username',validators=[DataRequired(),Length(3,24)])
    email = StringField('Email',validators=[DataRequired(),Email()])
    password = PasswordField('Password',validators=[DataRequired(),Length(6,24)])
    repeat_password = PasswordField('Repeat-password',validators=[DataRequired(),EqualTo('password')])
    submit = SubmitField('Submit')

    def create_user(self):
        user = User()
        user.username = self.username.data
        user.email = self.email.data
        user.password = self.password.data
        db.session.add(user)
        db.session.commit()
        return user

    def validate_username(self,field):
        if User.query.filter_by(username=field.data).first():
            raise ValidationError('Username has been exist!')

    def validate_email(self,field):
        if User.query.filter_by(email=field.data).first():
            raise ValidationError('Email has been exist!')



class LoginForm(FlaskForm):
    email = StringField('Email',validators=[DataRequired(),Email()])
    password = PasswordField('Password',validators=[DataRequired(),Length(6,24)])
    remember_me = BooleanField('Remember-me')
    submit = SubmitField('Submit')
    
    def validate_email(self,field):
        if not User.query.filter_by(email=field.data).first():
            raise ValidationError('Email has been not  exist!')

    def validate_password(self,field):
        user = User.query.filter_by(email=self.email.data).first()
        if user and not user.check_password(field.data):
            raise ValidationError('Password error!')

class CourseForm(FlaskForm):
    name = StringField('course name',validators=[DataRequired(),Length(5,32)])
    description = TextAreaField('course description',validators=[DataRequired(),Length(20,256)])
    image_url = StringField('cover image',validators=[DataRequired(),URL()])
    author_id = IntegerField('author ID',validators=[DataRequired(),NumberRange(min=1,message='invalid user ID')])
    submit = SubmitField('commit')

    def validate_author_id(self,field):
        if not User.query.get(self.author_id.data):
            raise ValidationError('user is not exist!')

    def create_course(self):
        course = Course()
        self.populate_obj(course)
        db.session.add(course)
        db.session.commit()
        return course

    def update_course(self,course):
        self.populate_obj(course)
        db.session.add(course)
        db.session.commit()
        return course



 

