from flask import Blueprint
from flask import render_template
from sysdocker.decorators import admin_required
from flask import request,current_app
from sysdocker.models import Course
from flask import redirect,url_for,flash
from sysdocker.forms import CourseForm
from sysdocker.forms import db

admin = Blueprint('admin',__name__,url_prefix='/admin')
