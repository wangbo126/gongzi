from flask import Blueprint
from flask import render_template
from sysdocker.decorators import admin_required
from flask import request,current_app
from sysdocker.models import Course
from flask import redirect,url_for,flash
from sysdocker.forms import CourseForm
from sysdocker.forms import db

containers = Blueprint('containers',__name__,url_prefix='/containers')

@containers.route('/')
@admin_required
def containers():
    page = request.args.get('page',default=1,type=int)
    pagination = Containers.query.paginate(
            page=page,
            per_page=current_app.config['ADMIN_PER_PAGE'],
            error_out=False
            )
    return render_template('admin/containers.html',pagination=pagination)


@containers.route('/create',methods=['GET','POST'])
@admin_required
def create_container():
    pass
#    form = CourseForm()
#    if form.validate_on_submit():
#        form.create_course()
#        flash('course is created successful!','success')
#        return redirect(url_for('admin.courses'))
#    return render_template('admin/create_course.html',form=form)

@containers.route('/<string:short_id>/edit',methods=['GET','POST'])
@admin_required
def edit_container(short_id):
    pass
#    course = Course.query.get_or_404(course_id)
#    form = CourseForm(obj=course)
#    if form.validate_on_submit():
#        form.update_course(course)
#        flash('course update successful!','success')
#        return redirect(url_for('admin.courses'))
#    return render_template('admin/edit_course.html',form=form,course=course)

@containers.route('/<string:short_id>/delete')
@admin_required
def delete_container(short_id):
    pass
#    course = Course.query.get_or_404(course_id)
#    db.session.delete(course)
#    db.session.commit()
#    flash('course is deleted successful!','success')
#    return redirect(url_for('admin.courses'))
