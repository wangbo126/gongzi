# -*- coding: utf-8 -*-

from openpyxl import load_workbook
from openpyxl import Workbook
import datetime

def combine():
    wb1 = load_workbook("courses.xlsx")
    ws1 = wb1['students']
    ws2 = wb1['time']
    ws3 = wb1.copy_worksheet(ws1)
    ws3.title = 'combine'

    lr1 = list(ws1.rows)
    lr2 = list(ws2.rows)
    row_num_ws1 = len(lr1)
    row_num_ws2 = len(lr2)

    print("combine sheet...")
    i = 1
    while i < row_num_ws1:
        j = 1
        course_name = lr1[i][1].value
        while j < row_num_ws2:
            if course_name == lr2[j][1].value :
                ws3.cell(row=i+1,column=4,value=lr2[j][2].value)
                break
            j += 1
        i += 1

    ws3.cell(row=1,column=4,value=lr2[0][2].value)  #biao tou filed
   
    wb1.save("courses.xlsx")
    print("combine sheet finished!")

def split():
    wb_all= load_workbook("courses.xlsx")
    ws_combine = wb_all['combine']
    lr_combine = list(ws_combine.rows)
    row_num_ws_combine = len(lr_combine)

    years_set = set()
    i=1
    while i < row_num_ws_combine:
        years_set.add((lr_combine[i][0].value).year)
        i += 1
    years_list = list(years_set)

    i=0
    years_num = len(years_list)
    wb_dict = {}
    while i < years_num:
        key = years_list[i]
        #wbnew = Workbook(str(years_list[i]),write_only=False) 
        wb_year = Workbook(write_only=False) 
        ws_year = wb_year.create_sheet(str(years_list[i])) 
        wb_dict[key] = str(years_list[i]) + '.xlsx'
        wb_year.save(wb_dict[key])
        i += 1

    y = 0
    while y < years_num:
        i = 1 # for index of lr_combine[i]
        j = 2 # for index of ws_year
        wb_year = load_workbook(wb_dict[years_list[y]])
        ws_year = wb_year[str(years_list[y])]
        while i < row_num_ws_combine:
           if years_list[y] == (lr_combine[i][0].value).year:
               ws_year.cell(row=j,column=1,value=lr_combine[i][0].value)
               ws_year.cell(row=j,column=2,value=lr_combine[i][1].value)
               ws_year.cell(row=j,column=3,value=lr_combine[i][2].value)
               ws_year.cell(row=j,column=4,value=lr_combine[i][3].value)
           i += 1
           j += 1
        ws_year.cell(row=1,column=1,value=lr_combine[0][0].value)
        ws_year.cell(row=1,column=2,value=lr_combine[0][1].value)
        ws_year.cell(row=1,column=3,value=lr_combine[0][2].value)
        ws_year.cell(row=1,column=4,value=lr_combine[0][3].value)

        wb_year.save(wb_dict[years_list[y]])
        print("wb_year.save for {}".format(wb_dict[years_list[y]]))
        y += 1
        
               











    

if __name__ == '__main__':
    combine()
    split()




