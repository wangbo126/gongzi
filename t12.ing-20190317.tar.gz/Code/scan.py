#!/usr/bin/env python3
import socket
import os
import sys

class Args(object):
    def __init__(self):
        self.args = sys.argv[1:]
        self.get_args(self.args)

    def get_args(self,line_args):
        #mytmp_list = []
        try:
            index = line_args.index('--host')
            self.ip = line_args[index+1]
        except ValueError:
            print("args --host error!")
            exit(-1)

        #mytmp_list.append(self.config_file)
        try:
            index = line_args.index('--port')
            self.port = line_args[index+1]
        except ValueError:
            print("args --port error!")
            exit(-2)
        return None

def scan(host,port):
    #s = socket.socket()
    #s.settimeout(0.1)  
    pass


# ------------------------

if __name__ == '__main__':
    if len(sys.argv) <= 1 :
        print("Usage:{} --host x.x.x.x --port single or range[20-25]".format(sys.argv[0]))
    else:
        chuli_args = Args()
        print(chuli_args.ip)
        print(chuli_args.port)
        
        #scan(host,port)
