import socket
import os

def testparm():


def scan(host,port):
    s = socket.socket()
    s.settimeout(0.1)


if __name__ == '__main__':
    testparm()
    scan(host,port)

