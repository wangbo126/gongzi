#!/usr/bin/env python3
import socket
import os
import sys
import re

class Args(object):
    def __init__(self):
        self.args = sys.argv[1:]
        self.get_args(self.args)

    def varify_ip(self,ipstr):
        m = re.match(r"([0-9]{1,3}\.){3}([0-9]{1,3}$)",ipstr)
        if m :
            return m.group(0)
        else:
            print("ipaddress Parameter Error")
            exit(1)

    def get_args(self,line_args):
        try:
            index = line_args.index('--host')
            self.ip = str(line_args[index+1])
            print(">>> self.ip = {} <<<".format(self.ip))
            self.varify_ip(self.ip)

        except ValueError:
            print("Parameter error!")
            exit(-1)
        try:
            index = line_args.index('--port')
            self.ports_tmp = line_args[index+1]
            self.ports = []
            #self.ports_tmp.append(line_args[index+1])
            self.ports = self.ports_tmp.split('-')

        except ValueError:
            print("Parameter error!")
            exit(-2)
        return None



def scan(host,port):
    #s = socket.socket()
    #s.settimeout(0.1)  
    HOST = host
    PORT = port
    #print("port={}".format(port))
    s = None
    for res in socket.getaddrinfo(HOST,PORT,socket.AF_UNSPEC,socket.SOCK_STREAM):
        af,socktype,proto,canonname,sa = res
        try:
            s = socket.socket(af,socktype,proto)
            s.settimeout(0.1)  
        except OSError as msg:
            s = None
            continue
        try:
            s.connect(sa)
        except OSError as msg:
            s.close()
            s = None
            continue
        break
    if s is None:
        print('{} closed'.format(PORT))
        #sys.exit(1)
        return None
    else:
        print('{} open'.format(PORT))
        s.close()
    return None


# ------------------------
if __name__ == '__main__':
    if len(sys.argv) <= 1 :
        print("Usage:{} --host x.x.x.x --port single or range[20-25]".format(sys.argv[0]))
    else:
        chuli_args = Args()
        #print(chuli_args.ip)
        #print(chuli_args.ports[0])
        i = int(chuli_args.ports[0])
        ports_num = len(chuli_args.ports)
        if ports_num > 1:
            while i <= int(chuli_args.ports[1]) :
                scan(chuli_args.ip,i)
                i += 1
        else:
            scan(chuli_args.ip,i)



        
        #scan(host,port)
