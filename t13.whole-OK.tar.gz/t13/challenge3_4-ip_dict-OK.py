# -*- coding: utf-8 -*-

import re
from datetime import datetime

def open_parser(filename):
    with open(filename) as logfile:
        pattern = (r''
                   r'(\d+.\d+.\d+.\d+)\s-\s-\s'  
                   r'\[(.+)\]\s' 
                   r'"GET\s(.+)\s\w+/.+"\s' 
                   r'(\d+)\s'   
                   r'(\d+)\s'   
                   r'"(.+)"\s' 
                   r'"(.+)"'  
                   )
        parsers = re.findall(pattern,logfile.read())
    return parsers

def main():
    logs = open_parser('/home/shiyanlou/Code/nginx.log')
    ip_dict = {}
    url_dict = {}
    count_dict = {}
    lines_num = len(logs)
    i = 0
    while i < lines_num:
        m = re.match(r'11\/Jan\/2017',logs[i][1])
        if m:
            #print("{}: {}".format(i,logs[i]))
            ipaddr = logs[i][0]
            if ipaddr in count_dict.keys():
                count_dict[ipaddr] += 1
            else:
                count_dict[ipaddr] =1
        i += 1

    visit_ip = 0
    visit_count = 0
    for key,value in count_dict.items():
        if value > visit_count:
            visit_ip = key
            visit_count = value
    ip_dict[visit_ip] = visit_count


    return ip_dict,url_dict

if __name__ == '__main__':
    ip_dict,url_dict = main()
    print(ip_dict,url_dict)






