# -*- coding: utf-8 -*-

import re
from datetime import datetime

def open_parser(filename):
    with open(filename) as logfile:
        pattern = (r''
                   r'(\d+.\d+.\d+.\d+)\s-\s-\s'  # ip address
                   r'\[(.+)\]\s' # time
                   r'"GET\s(.+)\s\w+/.+"\s' # request path
                   r'(\d+)\s'   # status code
                   r'(\d+)\s'   # data size
                   r'"(.+)"\s'  # request head
                   r'"(.+)"'    # client infomation
                   )
        parsers = re.findall(pattern,logfile.read())
    return parsers

def main():
    logs = open_parser('/home/shiyanlou/Code/nginx.log')
    ip_dict = {}
    url_dict = {}
    lines_num = len(logs)
    i = 0
    while i < lines_num:
        print("{}: {}".format(i,logs[i]))
        i += 1

    return ip_dict,url_dict

if __name__ == '__main__':
    ip_dict,url_dict = main()
    print(ip_dict,url_dict)






