# -*- coding:utf-8 -*-
import scrapy

class ShiyanlouCoursesSpider(scrapy.Spider):
    name = "myspider for github"
    @property
    def start_urls(self):
        url_tmpl = []
        u1 = 'https://github.com/shiyanlou?tab=repositories'
        #urls = (url_tmpl.format(i) for i in range(1,25))
        #for url in urls:
        #    yield scrapy.Request(url=url,callback=self.parse)
        u2 = 'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNy0wNi0wNlQyMjoyMToxNlrOBZKV2w%3D%3D&tab=repositories'
        u3 = 'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNy0wNi0wNlQyMjoyMToxNlrOBZKV2w%3D%3D&tab=repositories'
        u4 = 'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNy0wNi0wNlQyMjoyMToxNlrOBZKV2w%3D%3D&tab=repositories'
        url_tmpl.append(u1)
        url_tmpl.append(u2)
        url_tmpl.append(u3)
        url_tmpl.append(u4)
        return (url_tmpl[i] for i in range(0,3))

    def parse(self,response):
        for gititem in response.css('div#user-repositories-list'):
            yield {
                    'name': gititem.xpath('//a[@itemprop="name codeRepository"]/text()').re('[\S].+'),
                    'update_time': gititem.xpath('//relative-time/@datetime').extract()
                    }
