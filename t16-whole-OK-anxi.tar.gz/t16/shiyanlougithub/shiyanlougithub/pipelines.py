# -*- coding: utf-8 -*-
from datetime import datetime
from sqlalchemy.orm import sessionmaker
from shiyanlougithub.models import Repository,engine
from shiyanlougithub.items import ShiyanlougithubItem



class ShiyanlougithubPipeline(object):
    def process_item(self, item, spider):
        #print("************ item['update_time'] = {} ******".format(item['update_time']))
        item['update_time'] = datetime.strptime(item['update_time'],'%Y-%m-%dT%H:%M:%SZ')
        self.session.add(Repository(**item))
        return item

    def open_spider(self,spider):
        Session = sessionmaker(bind=engine)
        self.session = Session()

    def close_spider(self,spider):
        self.session.commit()
        self.session.close()

