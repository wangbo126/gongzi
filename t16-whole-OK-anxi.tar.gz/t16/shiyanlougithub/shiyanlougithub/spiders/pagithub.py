# -*- coding: utf-8 -*-
import scrapy
from shiyanlougithub.items import ShiyanlougithubItem


class PagithubSpider(scrapy.Spider):
    name = 'pagithub'

    @property
    def start_urls(self):
        return ['https://github.com/shiyanlou?tab=repositories',
                'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNy0wNi0wNlQyMjoyMToxNlrOBZKV2w%3D%3D&tab=repositories',
                'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNS0wMS0yNlQwODoxNzo1M1rOAcd_9A%3D%3D&tab=repositories',
                'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNC0xMS0yNFQwNzowMDoxN1rOAZz3Yw%3D%3D&tab=repositories'
        ]

    def parse(self,response):
        for i in response.css('li.col-12'):
            yield  ShiyanlougithubItem({
                'name': i.css('a::text').extract_first().strip(),
                'update_time': i.css('relative-time::attr(datetime)').extract_first()
            })
