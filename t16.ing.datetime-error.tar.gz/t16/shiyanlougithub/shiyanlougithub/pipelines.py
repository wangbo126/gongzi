# -*- coding: utf-8 -*-
from datetime import datetime
from sqlalchemy.orm import sessionmaker
from shiyanlougithub.models import Repository,engine
from shiyanlougithub.items import ShiyanlougithubItem



class ShiyanlougithubPipeline(object):
    def process_item(self, item, spider):
        #item['id'] = int(item['id'])
        item['name'] = str(item['name'])
        #item['update_time'] = datetime.strptime(item['update_time'].split()[0],'%Y-%m-%d').date()
        item['update_time'] = datetime(item['update_time'])
        self.session.add(Repository(**item))
        return item

    def open_spider(self,spider):
        Session = sessionmaker(bind=engine)
        self.session = Session()

    def close_spider(self,spider):
        self.session.commit()
        self.session.close()

