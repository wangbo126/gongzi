# -*- coding: utf-8 -*-
import scrapy
from shiyanlougithub.items import ShiyanlougithubItem


class PagithubSpider(scrapy.Spider):
    name = 'pagithub'
    #allowed_domains = ['github.com']
    #start_urls = ['http://github.com/']

    @property
    def start_urls(self):
        url_tmpl = []
        u1 = 'https://github.com/shiyanlou?tab=repositories'
        u2 = 'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNy0wNi0wNlQyMjoyMToxNlrOBZKV2w%3D%3D&tab=repositories'
        u3 = 'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNy0wNi0wNlQyMjoyMToxNlrOBZKV2w%3D%3D&tab=repositories'
        u4 = 'https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNy0wNi0wNlQyMjoyMToxNlrOBZKV2w%3D%3D&tab=repositories'
        url_tmpl.append(u1)
        url_tmpl.append(u2)
        url_tmpl.append(u3)
        url_tmpl.append(u4)
        return (url_tmpl[i] for i in range(0,3))

    def parse(self,response):
        for gititem in response.css('div#user-repositories-list'):
            yield  ShiyanlougithubItem({
                    'name': gititem.xpath('//a[@itemprop="name codeRepository"]/text()').re('[\S].+'),
                    'update_time': gititem.xpath('//relative-time/@datetime').extract()
                    })
