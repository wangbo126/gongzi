# *** below is tiaozhan32 ***
#from flask import Blueprint
#from flask import render_template
#from simpledu.models import Course,User,Live
#from flask_login import login_required

#live = Blueprint('live',__name__,url_prefix='/lives')

#@live.route('/<livename>')
#@login_required
#def index(livename):
#    live = Live.query.filter_by(live_name=livename).first()
#    return render_template('admin/edit_live.html',live=live)
# ^^^^^^^^^^^^^^^^^^^^^^^^^^^
# ****below is tiaozhan33 *******
from flask import Blueprint,render_template
from simpledu.models import Course,User,Live
from flask_login import login_required

live = Blueprint('live',__name__,url_prefix='/live')

@live.route('/')
def index():
    return render_template('live/index.html')

#@live.route('/lives/<livename>')
#@login_required
#def index(livename):
#    live = Live.query.filter_by(live_name=livename).first()
#    return render_template('admin/edit_live.html',live=live)
