#!/usr/bin/env python3

import sys
from pymongo import MongoClient

def get_rank(user_id):
    client = MongoClient()
    db = client.shiyanlou
    #contests = db.contests

    user_set = set()
    list_dict = db.contests.find()
    for ld in list_dict:
        user_set.add(ld['user_id'])  #get user_id from all of record

    user_sum = []
    for i in user_set:
        user_i_ld = db.contests.find({'user_id':i})
        score_sum = 0
        time_sum = 0
        for user_i_item in user_i_ld:
            score_sum = score_sum + user_i_item['score']
            time_sum = time_sum + user_i_item['submit_time']
        user_sum.append({'user_id':i,'score_sum':score_sum,'time_sum':time_sum})    #jisuan every user's score and time,then store to user_sum list-dict

    num = len(user_sum)
    #for i in range(num):         #before sort output
    #    print(user_sum[i])

    user_rank = {}
    i = 0
    while i < num :
        j = i +1
        while j < num :
            if user_sum[i]['score_sum'] < user_sum[j]['score_sum'] :
                user_sum[i],user_sum[j] = user_sum[j],user_sum[i]
            elif (user_sum[i]['score_sum'] == user_sum[j]['score_sum']) and (user_sum[i]['time_sum'] > user_sum[j]['time_sum']) :
                user_sum[i],user_sum[j] = user_sum[j],user_sum[i]
            j = j + 1
        user_rank[user_sum[i]['user_id']] = [i+1,user_sum[i]['score_sum'],user_sum[i]['time_sum']] 
        i = i + 1
    # mao pao sort

    #for i in range(num):       #after sort output
    #    print(user_sum[i])
    
    #rank = 0
    #score = 0
    #submit_time = 0
    #rank = user_rank[int(user_id)][0]
    #score = user_rank[int(user_id)][1]
    #submit_time = user_rank[int(user_id)][2]

    #return rank,score,submit_time
    return user_rank[int(user_id)]

if __name__ == '__main__':

    #TODO
    #print(len(sys.argv))
    if len(sys.argv) != 2:
        print("sys.argv error")
        print("useage:{} user_id".format(sys.argv[0]))
        exit(1)
    else:
        user_id = sys.argv[1]
        userdata = get_rank(user_id)
        print(userdata)

