# lou_challenge_ele
## 楼 + 挑战题目
- `web_run.py` 文件为 Flask 启动文件
- `ele.py` 中提供了优惠券爬虫，无需修改
- `static` 中提供了网站所需的 CSS, JS 静态文件
- `templates` 中提供了网页模版文件