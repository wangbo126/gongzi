from flask import Blueprint,render_template
from simpledu.models import Course,User

user = Blueprint('user', __name__, url_prefix='/user')

@user.route('/<user_name>')
def user_index(user_name):
    find_user = User.query.filter_by(username = user_name)
    find_courses = Course.query.filter_by(author_id = find_user[0].id)

    return render_template('user/detail.html',find_user=find_user,find_courses=find_courses)

