from flask import Blueprint
from flask import render_template
from simpledu.models import Course,User,Live
from flask_login import login_required



live = Blueprint('live',__name__,url_prefix='/lives')

@live.route('/<livename>')
@login_required
def index(live_name):
    live = User.query.filter_by(live_name=livename)
    return render_template('admin/edit_live.html',live=live)

#def detail(course_id):
#    course = Course.query.get_or_404(course_id)
#    return render_template('course/detail.html',course=course)


#@course.route('/<int:course_id>')
#def detail(course_id):
#    course = Course.query.get_or_404(course_id)
#    return render_template('course/detail.html', course=course)

