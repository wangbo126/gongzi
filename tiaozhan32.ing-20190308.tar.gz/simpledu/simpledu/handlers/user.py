from flask import Blueprint
from flask import render_template
from simpledu.models import Course,User
from flask_login import login_required
#from simpledu.models import Chapter



user = Blueprint('user',__name__,url_prefix='/users')

@user.route('/<username>')
@login_required
def index(username):
    user_username = User.query.get_or_404(username)
    return render_template('admin/edit_user.html',user_username=user_username)

#def detail(course_id):
#    course = Course.query.get_or_404(course_id)
#    return render_template('course/detail.html',course=course)


#@course.route('/<int:course_id>')
#def detail(course_id):
#    course = Course.query.get_or_404(course_id)
#    return render_template('course/detail.html', course=course)

