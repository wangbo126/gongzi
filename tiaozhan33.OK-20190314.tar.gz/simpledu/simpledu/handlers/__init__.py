from .front import front
from .course import course
from .admin import admin
from .user import user
from .live import live
from .ws import ws

